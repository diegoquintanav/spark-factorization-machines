
# Spark-factorization-machines
> Diplomado Big Data PUC 2017

> Andrés Altamirano, Diego Quintana



<h1>Table of Contents<span class="tocSkip"></span></h1>
<div class="toc" style="margin-top: 1em;"><ul class="toc-item"><li><span><a href="#Spark-factorization-machines" data-toc-modified-id="Spark-factorization-machines-1"><span class="toc-item-num">1&nbsp;&nbsp;</span>Spark-factorization-machines</a></span><ul class="toc-item"><li><span><a href="#Checkeamos-que-el-SparkContext-este-cargado-correctamente" data-toc-modified-id="Checkeamos-que-el-SparkContext-este-cargado-correctamente-1.1"><span class="toc-item-num">1.1&nbsp;&nbsp;</span>Checkeamos que el SparkContext este cargado correctamente</a></span></li><li><span><a href="#Inicializacion" data-toc-modified-id="Inicializacion-1.2"><span class="toc-item-num">1.2&nbsp;&nbsp;</span>Inicializacion</a></span></li><li><span><a href="#Cargamos-el-set-de-datos" data-toc-modified-id="Cargamos-el-set-de-datos-1.3"><span class="toc-item-num">1.3&nbsp;&nbsp;</span>Cargamos el set de datos</a></span><ul class="toc-item"><li><span><a href="#Entrenamiento-de-un-modelo" data-toc-modified-id="Entrenamiento-de-un-modelo-1.3.1"><span class="toc-item-num">1.3.1&nbsp;&nbsp;</span>Entrenamiento de un modelo</a></span><ul class="toc-item"><li><span><a href="#Notas-sobre-auROC-y-auPR" data-toc-modified-id="Notas-sobre-auROC-y-auPR-1.3.1.1"><span class="toc-item-num">1.3.1.1&nbsp;&nbsp;</span>Notas sobre auROC y auPR</a></span></li></ul></li></ul></li><li><span><a href="#Exploración-de-parámetros" data-toc-modified-id="Exploración-de-parámetros-1.4"><span class="toc-item-num">1.4&nbsp;&nbsp;</span>Exploración de parámetros</a></span><ul class="toc-item"><li><span><a href="#Tasa-de-Aprendizaje-(alpha)" data-toc-modified-id="Tasa-de-Aprendizaje-(alpha)-1.4.1"><span class="toc-item-num">1.4.1&nbsp;&nbsp;</span>Tasa de Aprendizaje (alpha)</a></span></li><li><span><a href="#Dimensionalidad-de-los-factores-latentes-(factorLength)" data-toc-modified-id="Dimensionalidad-de-los-factores-latentes-(factorLength)-1.4.2"><span class="toc-item-num">1.4.2&nbsp;&nbsp;</span>Dimensionalidad de los factores latentes (factorLength)</a></span></li><li><span><a href="#Parámetro-de-Regularización-(regParam)" data-toc-modified-id="Parámetro-de-Regularización-(regParam)-1.4.3"><span class="toc-item-num">1.4.3&nbsp;&nbsp;</span>Parámetro de Regularización (regParam)</a></span></li><li><span><a href="#Búsqueda-en-Grilla" data-toc-modified-id="Búsqueda-en-Grilla-1.4.4"><span class="toc-item-num">1.4.4&nbsp;&nbsp;</span>Búsqueda en Grilla</a></span></li></ul></li><li><span><a href="#Utilicemos-los-mejores-parámetros" data-toc-modified-id="Utilicemos-los-mejores-parámetros-1.5"><span class="toc-item-num">1.5&nbsp;&nbsp;</span>Utilicemos los mejores parámetros</a></span></li></ul></li></ul></div>

## Checkeamos que el SparkContext este cargado correctamente


```
print sc
```

    <pyspark.context.SparkContext object at 0x34a1790>


## Inicializacion

**Observación: A lo largo del notebook se le pide que asigne a algunas variables ciertos valores que son obtenidos en la ejecución, tenga en cuenta que esto será evaluado.**

Cargamos la librería que implementa las máquinas de factorización e importamos las distintas funciones.


```
sc.addPyFile("./fm/fm_parallel_sgd.py")

```


```
import fm_parallel_sgd as fm
from fm_parallel_sgd import *
```

Seteamos algunos parametros de matplotlib para dibujar las figuras en el notebook:


```
import matplotlib.pylab as pylab
pylab.rcParams['figure.figsize']=(16.0, 12.0)
```

## Cargamos el set de datos

El set de datos es un RDD (Resilient Distributed Dataset) de LabeledPoints donde las etiquetas deben tener el valor -1 o 1.

Los vectores de características deben ser un SparseVector o DenseVector de la librería mllib.linalg.

Nuestro set de datos es de ratings de cervezas. Este set de datos posee los ratings por usuario y además incluye el estilo de la cerveza evaluada.


```
nrPartitions = 5
trainPath = 'beer-dataset/beers_with_styles.train'
trainAll = MLUtils.loadLibSVMFile(sc, trainPath, numFeatures=10426).repartition(nrPartitions)
testPath = 'beer-dataset/beers_with_styles.test'
test = MLUtils.loadLibSVMFile(sc, testPath, numFeatures=10426)

print trainAll.count()
print test.count()
print trainAll.first()
```

    44379
    2945
    (-1.0,(10426,[8,8332,10217],[1.0,1.0,1.0]))



```
print type(trainAll)
```

    <class 'pyspark.rdd.RDD'>



```
print trainAll.take(5)
```

    [LabeledPoint(-1.0, (10426,[8,8332,10217],[1.0,1.0,1.0])), LabeledPoint(1.0, (10426,[8,8333,10218],[1.0,1.0,1.0])), LabeledPoint(1.0, (10426,[8,8334,10219],[1.0,1.0,1.0])), LabeledPoint(1.0, (10426,[8,8335,10220],[1.0,1.0,1.0])), LabeledPoint(1.0, (10426,[9,8336,10221],[1.0,1.0,1.0]))]


**P2.1: Explique en sus palabras qué significa esta salida: (-1.0,(10426,[8,8332,10217],[1.0,1.0,1.0]))**

R: Si se observa en la documentacion de `MLUtils.loadLibSVMFile`


```
help(MLUtils.loadLibSVMFile)
```

    Help on function loadLibSVMFile in module pyspark.mllib.util:
    
    loadLibSVMFile(sc, path, numFeatures=-1, minPartitions=None, multiclass=None)
        Loads labeled data in the LIBSVM format into an RDD of
        LabeledPoint. The LIBSVM format is a text-based format used by
        LIBSVM and LIBLINEAR. Each line represents a labeled sparse
        feature vector using the following format:
        
        label index1:value1 index2:value2 ...
        
        where the indices are one-based and in ascending order. This
        method parses each line into a LabeledPoint, where the feature
        indices are converted to zero-based.
        
        :param sc: Spark context
        :param path: file or directory path in any Hadoop-supported file
                     system URI
        :param numFeatures: number of features, which will be determined
                            from the input data if a nonpositive value
                            is given. This is useful when the dataset is
                            already split into multiple files and you
                            want to load them separately, because some
                            features may not present in certain files,
                            which leads to inconsistent feature
                            dimensions.
        :param minPartitions: min number of partitions
        @return: labeled data stored as an RDD of LabeledPoint
        
        >>> from tempfile import NamedTemporaryFile
        >>> from pyspark.mllib.util import MLUtils
        >>> tempFile = NamedTemporaryFile(delete=True)
        >>> tempFile.write("+1 1:1.0 3:2.0 5:3.0\n-1\n-1 2:4.0 4:5.0 6:6.0")
        >>> tempFile.flush()
        >>> examples = MLUtils.loadLibSVMFile(sc, tempFile.name).collect()
        >>> tempFile.close()
        >>> type(examples[0]) == LabeledPoint
        True
        >>> print examples[0]
        (1.0,(6,[0,2,4],[1.0,2.0,3.0]))
        >>> type(examples[1]) == LabeledPoint
        True
        >>> print examples[1]
        (-1.0,(6,[],[]))
        >>> type(examples[2]) == LabeledPoint
        True
        >>> print examples[2]
        (-1.0,(6,[1,3,5],[4.0,5.0,6.0]))
    


Segun esto, 

*  `-1` es la clasificacion para ese conjunto de features
*  `10426` es la cantidad de `features` que se le pasa al metodo, el cual es la suma total de usuarios,  items y estilos de cerveza. Caso contrario el default es -1 lo que le indica al metodo que debe inferir la cantidad de features incluidas en el SVM cargado, el que puede ser menor en datasets divididos como es nuestro caso
*  `[8,8332,10217],[1.0,1.0,1.0]` es una tupla de dos listas, la primera contiene los ID de cada usuario, item y estilo, y la segunda la cantidad de veces que aparece en ese dato. Para todas las entradas esta lista esta llena de numeros 1.

Veamos cuanto tarda una iteración de este algoritmo en correr, para que tengamos una noción del tiempo.


```
temp = time.time()
model = trainFM_parallel_sgd (sc, trainAll, iterations=1, iter_sgd=1, alpha=0.01, regParam=0.01, factorLength=4,\
                      verbose=True, savingFilename = None, evalTraining=None)
print 'time :'; print  time.time()-temp;
```

    iter 	time 	train_logl 	val_logl
    0 	0 	0.693065 	0.693064
    1 	19 	0.677161 	0.676751
    Train set: 
    (rtv_pr_auc, rtv_auc, logl, mse, accuracy)
    (0.92023630512548082, 0.71101611920494556, 0.6771609658699479, 0.24201772017261783, 0.83691725928434357)
    Validation set:
    (0.92240132352752546, 0.71772542683902751, 0.67675055015541274, 0.24181279177507356, 0.83830929218383088)
    time :
    76.9000818729



```
help(trainFM_parallel_sgd)
```

    Help on function trainFM_parallel_sgd in module fm_parallel_sgd:
    
    trainFM_parallel_sgd(sc, data, iterations=50, iter_sgd=5, alpha=0.01, regParam=0.01, factorLength=4, verbose=False, savingFilename=None, evalTraining=None)
        Train a Factorization Machine model using parallel stochastic gradient descent.
        
        Parameters:
        data : RDD of LabeledPoints
            Training data. Labels should be -1 and 1
            Features should be either SparseVector or DenseVector from mllib.linalg library
        iterations : numeric
            Nr of iterations of parallel SGD. default=50
        iter_sgd : numeric
            Nr of iteration of sgd in each partition. default = 5
        alpha : numeric
            Learning rate of SGD. default=0.01
        regParam : numeric 
            Regularization parameter. default=0.01
        factorLength : numeric
            Length of the weight vectors of the FMs. default=4
        verbose: boolean
            Whether to ouptut iteration numbers, time, logloss for train and validation sets
        savingFilename: String
            Whether to save the model after each iteration
        evalTraining : instance of the class evaluation
            Plot the evaluation during the training (on a train and a validation set)
            The instance should be created before using trainFM_parallel_sgd
        
        returns: w
            numpy matrix holding the model weights
    


Definimos una función que nos ayude a interpretar las evaluaciones de un modelo.


```
def print_evaluate(test, model):
    rtv_pr_auc, rtv_auc, logl, mse, acc =  evaluate(test, model)
    print "Área bajo la curva del gráfico Precision vs Recall: %.3f" % rtv_pr_auc
    print "Área bajo la ROC curva: %.3f" % rtv_auc
    print "Log-perdida media: %.3f" % logl
    print "MSE: %.3f" % mse
    print "Exactitud (Accuracy): %.3f" % acc
```


```
print_evaluate(test, model)
```

    Área bajo la curva del gráfico Precision vs Recall: 0.931
    Área bajo la ROC curva: 0.706
    Log-perdida media: 0.675
    MSE: 0.241
    Exactitud (Accuracy): 0.858


**P2.2: ¿Cuál es el tiempo de entrenamiento de cada iteración?**

R: Segun lo indicado gracias al flag `verbose=True`, para una iteracion se demora 19 segundos, aunque esto no considera otros tiempos adicionales, los que suman alrededor de 77 segundos

### Entrenamiento de un modelo

Entrenemos un modelo por 10 iteraciones utilizando máquinas de factorización. 

Este modelo será evaluado después de cada iteración utilizando validación cruzada y será guardado.

Puedes ver los gráficos de las distintas métricas a lo largo del entrenamiento.

**Métricas:**


**logl**: Log-perdida media

**rtv_pr_auc**: Área bajo la curva del gráfico Precision vs Recall

**rtv_auc**: Área bajo la ROC curva

**MSE**: Error cuadrático medio

**Accuracy**: Exactitud

#### Notas sobre auROC y auPR

En tareas de clasificación binaria, se tiene que la *precisión* es la fracción de instancias obtenidas en alguna tarea en específico. Dicho de otra forma

$$ \mbox{precision} = \frac{\mbox{TP}}{\mbox{TP}+\mbox{FP}}$$

mientras que *Recall* se refiere a la fracción de instancias relevantes obtenidas, o bien

$$ \mbox{TPR} = \mbox{recall} = \frac{\mbox{TP}}{\mbox{TP}+\mbox{FN}}$$

donde $\mbox{TP}$ se refiere a positivos verdaderos o *true positives*, y $\mbox{FN}$ a falsos negativos  (*false negatives*). *Recall* se conoce también como *true positive rate* o TPR.

Ambos *precision* y *recall* tienen una relación inversa, tal que el *recall* disminuye a medida que la *precision* aumenta. En este sentido, para un clasificador es posible graficar su desempeño en términos de la curva *precision vs recall*.

Esta curva puede transformarse al espacio más conocido como la curva ROC (*receiving operating characteristic curve*), en el cual se grafica *recall* como TPR o *true positive rate* versus FPR o *false positive rate*

$$  \mbox{FPR} = {\frac {\mbox{FP}}{\mbox{N}}}={\frac {\mbox{FP}}{\mbox{FP+TN}}}$$

![roc_vs_pr](img/roc_vs_pr.png)


De acuerdo a [este paper](http://pages.cs.wisc.edu/~jdavis/davisgoadrichcamera2.pdf), ambas curvas no son equivalentes y tienen distintas interpretaciones, siendo PR más útil en casos donde existe un gran desbalance entre clases.

Se dice, finalmente, que las áreas bajo la curva indican un grado de rendimiento del clasificador considerando distintos umbrales de aceptación o *thresholds*, usados para determinar si una instancia es declarada relevante o no. A mayor área mejores son las alternativas disponibles considerando los distintos thresholds disponibles.




```
temp = time.time()
evalTraining = evaluation(trainAll)
evalTraining.modulo = 1
trainFM_parallel_sgd (sc, trainAll, iterations=10, iter_sgd= 3, alpha=0.01, regParam=0.01, factorLength=4,\
                      verbose=True, savingFilename = 'models/beers', evalTraining=evalTraining)
print 'Tiempo total: '; print  time.time()-temp;
```

    iter 	time 	train_logl 	val_logl
    0 	0 	0.693079 	0.693080
    1 	62 	0.556620 	0.557909
    2 	115 	0.491154 	0.497711
    3 	169 	0.451678 	0.463719
    4 	217 	0.425736 	0.442452
    5 	263 	0.407478 	0.428384
    6 	310 	0.394455 	0.418916
    7 	357 	0.384810 	0.412270
    8 	404 	0.377291 	0.407326
    9 	451 	0.371253 	0.403499
    10 	497 	0.366211 	0.400391
    Train set: 
    MSE: 0.115154 
    logl: 0.366211 
    rtv_pr_auc: 0.955135 
    rtv_auc: 0.806974 
    Accuracy: 0.806974
    
    Validation set: 
    MSE: 0.125844 
    logl: 0.400391 
    rtv_pr_auc: 0.934596 
    rtv_auc: 0.759296 
    Accuracy: 0.759296
    
    Tiempo total: 
    526.324791908



![png](output_27_1.png)


**P2.3: ¿Cuál es el tiempo de entrenamiento y el resultado de las 4 distintas métricas para el modelo en la iteración 10?** 

R: 

* Iteration: 10
* Time: 497

Para ambos sets se tiene

*  Train set: 
 *  MSE: 0.115154 
 *  logl: 0.366211 
 *  rtv_pr_auc: 0.955135 
 *  rtv_auc: 0.806974 
 *  Accuracy: 0.806974

*  Validation set: 
 *  MSE: 0.125844 
 *  logl: 0.400391 
 *  rtv_pr_auc: 0.934596 
 *  rtv_auc: 0.759296 
 *  Accuracy: 0.759296

**P2.4: ¿Siempre se reduce el error en el set de entrenamiento entre dos iteraciones? ¿Y en el de validación? Explique.**

**R:** Para ambos sets el error va disminuyendo siempre, aunque en menor medida en las iteraciones finales.

Podemos utilizar el modelo guardado con el mejor rendimiento en el set de validación y lo utilzamos para ser evaluado con respecto al set de test. **Ojo:** Debes reemplazar **best_iter** con la iteración en que se obtiene el mejor resultado en el set de validación.


```
best_iter = 10 # Poner el mejor valor en el paso anterior
model = loadModel('models/beers_iteration_%d' % best_iter)
```


```
print_evaluate(test, model)
```

    Área bajo la curva del gráfico Precision vs Recall: 0.949
    Área bajo la ROC curva: 0.761
    Log-perdida media: 0.374
    MSE: 0.117
    Exactitud (Accuracy): 0.866


**P2.5: ¿Cuál es el rendimiento en el set de test? ¿Por qué se utiliza el test para medir el rendimiento?**

R: El rendimiento es de un 86%. El set de test se utiliza para poner a prueba el modelo. El objetivo es comparar si el resultado entregado por el modelo corresponde con la verdad en el set de test. El indicador de precisión mide el porcentaje de muestras que el modelo pudo evaluar con un resultado igual a la verdad del set.

## Exploración de parámetros

Ahora buscaremos hacer una sensibilidad con los distintos parámetros que tiene este algoritmo y así ser capaces de encontrar un mejor modelo.

Para hacer esta exploración más rápida, utilizaremos un subconjunto de los datos de entrenamiento un 10%.


```
trainSample = trainAll.sample(False, 0.1)
```

### Tasa de Aprendizaje (alpha)

Veamos como influye la tasa de aprendizaje en el rendimiento de este método. Sientase en confianza de cambiar los valores en la variable **alpha_list** (agregar, quitar o modificar) a ver si encuentra uno mejor que el que se obtiene con los valores entregados.


```
alpha_list = [0.001, 0.003, 0.006, 0.01, 0.03, 0.06, 0.1, 0.3, 0.6, 1]

model = plotAlpha(sc, trainSample, iterations=10, iter_sgd=1, alpha_list=alpha_list)
```


![png](output_41_0.png)


    best alpha :  0.100000
    best logloss :  0.464471


**P2.6 Interprete con sus palabras que ocurre al aumentar el valor del parámetro alfa.**

**R:** A medida que aumenta el valor de alpha, los valores de auPR y auROC aumentan en el caso de entrenamiento, pero se mantienen bajos durante test. Lo mismo ocurre con los errores, lo que hace pensar que a medida que aumenta `alpha` el clasificador está más propenso al *overfitting*, más aún si se considera la cantidad de clases en el dataset.

### Dimensionalidad de los factores latentes (factorLength)

Veamos como influye la dimensionalidad de los factores latentes en el rendimiento de este método. Sientase en confianza de cambiar los valores en la variable **factorLength_list** (agregar, quitar o modificar) a ver si encuentra uno mejor que el que se obtiene con los valores entregados. 


```
factorLength_list = [1, 5, 10, 15, 20, 30, 40]

model = plotFactorLength(sc, trainSample, factorLength_list=factorLength_list,\
              iterations=5, iter_sgd=1, alpha=0.01, regParam=0.)
```


![png](output_45_0.png)


    best factor length :  1.000000
    best logloss :  0.691129


**P2.7 Interprete con sus palabras que ocurre al aumentar el valor de la dimensionalidad de los factores.**

R: A medida que se incorporan más características a través de `factorLength`, la calidad de la clasificación mejora según lo visto en auPR y auROC, sin comprometer demasiado el error a medida que las características aumentan. Se podría decir que incorporar más características contribuye a la capacidad de generalizar del clasificador.

### Parámetro de Regularización (regParam)

Veamos como influye el parámetro de regularización en el rendimiento de este método. Sientase en confianza de cambiar los valores en la variable **regParam_list** (agregar, quitar o modificar) a ver si encuentra uno mejor que el que se obtiene con los valores entregados. 


```
regParam_list = [0, 0.0001, 0.001, 0.01, 0.1]

model = plotRegParam(sc, trainSample, regParam_list=regParam_list, iterations=5, iter_sgd=1, alpha=0.01, factorLength=4)
```


![png](output_49_0.png)


    best Regularization Parameter :  0.000100
    best logloss :  0.691464


**P2.8 Interprete con sus palabras que ocurre al aumentar el valor del factor de regularización.**

**R:**  A medida que aumenta el parámetro de regularización en L2 se produce un efecto de overfitting, en el que los pesos son ajustados privilegiando funciones más complejas, lo que produce un error más claro en los casos de validación. Esto se observa también en la tendencia de las métricas de error, las que aumentan considerablemente a medida que aumenta este parámetro. 

En el caso contrario, a medida que la regularización es más baja se privilegian pesos más bajos lo que produce ajustes menos sesgados y que presentan mejores capacidades de generalizar. 

El valor de auPR describe mejor esta situación, en la que la cantidad de falsos positivos aumenta y la cantidad de falsos negativos disminuye con mayor velocidad a medida que aumenta este parámetro, mientras que esta relación es más moderada para el caso de auROC, aunque igual manifiesta este mismo comportamiento. 

Se podría decir que este clasificador presenta una sensibilidad mayor a los cambios de este parámetro. Esto quiere decir que si bien el mejor valor resultante es del orden de 0.0001, existe un *tradeoff* con las métricas de clasificación, en las que un valor un poco mayor ($\approx$0.001) aumenta el error pero mejora los valores de auROC y auPR para los casos de validación. Esta sensibilidad también implica que existe un punto en el que esta mejora se transforma en todo lo contrario, por lo que se debe analizar con cuidado.



### Búsqueda en Grilla

Por último, podemos buscar la mejor combinación de parámetros (entre la tasa de aprendizaje y el parámetro de regularización) y así obtener el mejor modelo posible. Sientase en confianza de cambiar los valores en las variables **alpha_list** y **regParam_list** (agregar, quitar o modificar) a ver si encuentra uno mejor que el que se obtiene con los valores entregados. 



```
alpha_list = [0.01, 0.03, 0.06, 0.1]
regParam_list = [0, 0.0001, 0.001, 0.01]

bestModel = plotAlpha_RegParam(sc, trainSample, alpha_list=alpha_list,\
                       regParam_list=regParam_list, iterations=5, iter_sgd=10)
```

    LOGL :
    [[ 0.49506782  0.49607995  0.49602339  0.49924738]
     [ 0.43775762  0.43760574  0.43417191  0.42530118]
     [ 0.50377872  0.50151279  0.48410104  0.44208128]
     [ 0.60970893  0.60237485  0.56070248  0.48077982]]
    best alpha :  0.030000
    best Regularization Parameter :  0.010000
    best logloss :  0.425301


## Utilicemos los mejores parámetros

Usando los parámetros encontrados entrenemos un modelo tal y como lo hicimos al inicio. Reemplaza los mejores parámetros en las variables **best_alpha** y **best_regParam** a continuación.


```
best_alpha = 0.030000 # Rellenar con el mejor alfa obtenido en el paso anterior
best_regParam = 0.010000 # Rellenar con el mejor regParam obtenido en el paso anterior

temp = time.time()
evalTraining = evaluation(trainAll)
evalTraining.modulo = 2
trainFM_parallel_sgd (sc, trainAll, iterations=20, iter_sgd= 3, alpha=0.06, regParam=0.01, factorLength=4,\
                      verbose=True, savingFilename = 'models/beers_find', evalTraining=evalTraining)
print 'Tiempo total: '; print  time.time()-temp;
```

    iter 	time 	train_logl 	val_logl
    0 	0 	0.693081 	0.693082
    1 	61 	0.411097 	0.423837
    3 	148 	0.347013 	0.382920
    5 	237 	0.324062 	0.376534
    7 	324 	0.308281 	0.374784
    9 	410 	0.296440 	0.375343
    11 	497 	0.287252 	0.376989
    13 	588 	0.279567 	0.379276
    15 	677 	0.272658 	0.382021
    17 	770 	0.266261 	0.384903
    19 	859 	0.260152 	0.387653
    Train set: 
    MSE: 0.079146 
    logl: 0.260152 
    rtv_pr_auc: 0.981557 
    rtv_auc: 0.916145 
    Accuracy: 0.916145
    
    Validation set: 
    MSE: 0.117206 
    logl: 0.387653 
    rtv_pr_auc: 0.938361 
    rtv_auc: 0.777117 
    Accuracy: 0.777117
    
    Tiempo total: 
    929.052706957



![png](output_55_1.png)


Evaluemos este nuevo modelo. **Ojo:** Debes reemplazar **best_iter** con la iteración en que se obtiene el mejor resultado en el set de validación.


```
best_iter = 7 #best iteration
model = loadModel('models/beers_find_iteration_%d' % best_iter)
print_evaluate(test, model)
```

    Área bajo la curva del gráfico Precision vs Recall: 0.951
    Área bajo la ROC curva: 0.776
    Log-perdida media: 0.350
    MSE: 0.107
    Exactitud (Accuracy): 0.867


**P2.9 De los todos parámetros que probo anteriormente ¿Todos influyen lo mismo? ¿Cuál es el que más influye?**

**R:** Según lo analizado, 

*  Alpha influye más en la capacidad de generalización del clasificador, presentando un comportamiento más predecible
*  El parámetro de regularización L2 influye mucho más en esta capacidad y en el error, influyendo en la calidad del clasificador en general. Se vio que el clasificador es mucho más sensible a variaciones en este parámetro.
*  La cantidad de características consideradas en las clasificaciones contribuye a mejorar la calidad de las clasificaciones.

Utilicemos el modelo para hacer predicciones. Tomaremos las primeras 5.


```
predictFM(test, model).take(5)
```




    [0.69659366684914992,
     0.86293200038132034,
     0.57815393588521469,
     0.98458138487360347,
     0.86713766110390356]



**P2.10 ¿Qué cree que significan estos valores y como los utilizaría para recomendar?**

R: Corresponde a la probabilidad de que cada caso haya sigo correctamente predicho. Esto puede ser utilizado para establecer un criterio de **probabilidad mínima** al momento de establecer una recomendación como válida, con el fin de evitar hacer sugerencias cuando la probabilidad es baja y entregar una mala recomendación.

**P2.11 Explique en sus palabras como replicaría este procedimiento para armar un modelo de recomendación para libros.**

R: El dataset utilizado cuenta en su versión original con features numéricos acotados (`userId`, `itemId`, `styleID`). En el caso de libros no hay mucha diferencia pues se puede crear un dataset de la misma forma. El caso es genérico y sólo bastaría con obtener un dataset adecuado. 

Otra opción sería considerar el análisis de contenido, ya sea del libro completo, utilizando LDA para extraer tópicos y generando vectores de palabras en función de una reseña de cada libro.
